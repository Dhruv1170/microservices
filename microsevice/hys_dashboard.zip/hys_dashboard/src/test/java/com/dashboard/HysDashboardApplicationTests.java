package com.dashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HysDashboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
