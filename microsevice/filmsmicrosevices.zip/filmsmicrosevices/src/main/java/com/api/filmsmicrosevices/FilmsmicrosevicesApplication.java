package com.api.filmsmicrosevices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FilmsmicrosevicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(FilmsmicrosevicesApplication.class, args);
	}

}
